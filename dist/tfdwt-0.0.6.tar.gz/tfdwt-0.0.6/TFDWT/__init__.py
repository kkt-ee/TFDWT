"""ॐ

TFDWT: Fast Discrete Wavelet Transform TensorFlow Layers.
Copyright (C) 2025 Kishore Kumar Tarafdar

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>."""



# # import tensorflow as tf
# # import keras
# # import numpy as np

# from TFDWT.dbFBimpulseResponse import FBimpulseResponses
# from TFDWT.DWTFilters import FetchAnalysisSynthesisFilters
# from TFDWT.DWTop import DWTop 
## from TFDWT.dwt_operator import make_dwt_operator_matrix_A #deprecated


# from TFDWT.DWT1DFB import DWT1D, IDWT1D
# from TFDWT.DWT2DFB import DWT2D, IDWT2D
# from TFDWT.DWT3DFB import DWT3D, IDWT3D





__version__="0.0.6"